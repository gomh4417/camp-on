@echo off
setlocal
chcp 65001 >nul
title CAMP 차량 앱 설치

set "APK_PATH=%~dp0APK\group_drive_mvp_debug.apk"
set "ADB_EXE="

for /f "delims=" %%I in ('where adb 2^>nul') do if not defined ADB_EXE set "ADB_EXE=%%I"
if not defined ADB_EXE if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB_EXE=%ANDROID_HOME%\platform-tools\adb.exe"
if not defined ADB_EXE if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB_EXE=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"

if not exist "%APK_PATH%" (
  echo [오류] 차량 APK를 찾지 못했습니다: %APK_PATH%
  pause
  exit /b 1
)

if not defined ADB_EXE (
  echo [오류] Android adb를 찾지 못했습니다.
  echo Android Studio의 SDK Platform-Tools 설치 여부를 확인해주세요.
  pause
  exit /b 1
)

echo Pleos 시뮬레이터 연결을 기다립니다.
"%ADB_EXE%" wait-for-device

echo 차량 앱을 설치합니다.
"%ADB_EXE%" install -r "%APK_PATH%"
if errorlevel 1 (
  echo [오류] APK 설치에 실패했습니다. 시뮬레이터가 완전히 켜졌는지 확인해주세요.
  pause
  exit /b 1
)

echo 그룹 주행 화면을 실행합니다.
"%ADB_EXE%" shell am force-stop com.anchor.pleosvoice
"%ADB_EXE%" shell am start -n com.anchor.pleosvoice/.GroupDriveActivity

echo.
echo 설치와 실행이 완료되었습니다.
pause

