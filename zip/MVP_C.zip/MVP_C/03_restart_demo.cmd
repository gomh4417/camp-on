@echo off
setlocal
chcp 65001 >nul
title CAMP 데모 다시 시작

echo 공유 서버 데이터를 초기화합니다.
powershell.exe -NoProfile -Command "try { Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/reset' -Method Post -ContentType 'application/json' -Body '{}' | Out-Null; Write-Host '서버 초기화 완료' } catch { Write-Host '서버 초기화 생략: 01_start_server.cmd가 실행 중인지 확인해주세요.' }"

set "ADB_EXE="
for /f "delims=" %%I in ('where adb 2^>nul') do if not defined ADB_EXE set "ADB_EXE=%%I"
if not defined ADB_EXE if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB_EXE=%ANDROID_HOME%\platform-tools\adb.exe"
if not defined ADB_EXE if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB_EXE=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"

if not defined ADB_EXE (
  echo [오류] Android adb를 찾지 못해 차량 앱을 다시 열 수 없습니다.
  pause
  exit /b 1
)

echo 차량 앱을 종료하고 다시 실행합니다.
"%ADB_EXE%" shell am force-stop com.anchor.pleosvoice
"%ADB_EXE%" shell am start -n com.anchor.pleosvoice/.GroupDriveActivity

echo.
echo 데모가 처음 상태로 다시 시작되었습니다.
pause

