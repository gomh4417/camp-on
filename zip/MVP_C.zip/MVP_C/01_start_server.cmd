@echo off
setlocal
chcp 65001 >nul
title CAMP 그룹 주행 공유 서버

where node >nul 2>nul
if errorlevel 1 (
  echo [오류] Node.js를 찾지 못했습니다.
  echo https://nodejs.org 에서 LTS 버전을 설치한 뒤 다시 실행해주세요.
  echo.
  pause
  exit /b 1
)

echo 차량 앱과 모바일 앱의 공유 서버를 시작합니다.
echo 이 창은 체험이 끝날 때까지 닫지 마세요.
echo 상태 확인: http://127.0.0.1:8787/api/health
echo.

pushd "%~dp0server"
node server.mjs
set "SERVER_EXIT=%ERRORLEVEL%"
popd

echo.
echo 서버가 종료되었습니다. 종료 코드: %SERVER_EXIT%
pause
exit /b %SERVER_EXIT%

